#include <iostream>
using namespace std;

int decToBin(int n,int idx)
{
    int decimalNum[idx],binArray = idx;
    int n1 = n;
    idx--;
    for (int i = -1; i < binArray; i++)
    {
        if (n1%2 == 0)
        {
            decimalNum[idx] = 0;
        } else {
            decimalNum[idx] = 1;
        }
        
        idx--;n1=n1/2;    
    }
    // Print Bin Num
    int space = 1,binInt,decimalNum1;
    
    for (int i = 0; i < binArray; i++)
    {   
        decimalNum1 =+ decimalNum[i];
        binInt = decimalNum[i];
        cout << decimalNum[i];space++;
        if (space == 5)
        {
            cout << " "; space = 1;
        } 
    }

    return 0;
}

int main()
{
    int n; // Value
    int idx = 8,max = 2; // Binary length
    cout << "Input your text : "; cin >> n;
    cout << "Your Binary number is : ";

    decToBin(n,idx);max--;




    
    return 0;
}